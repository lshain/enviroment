#ifndef __HEADER_H
#define __HEADER_H

int processStream(char *byteStream, int length);
int manipulateStream(char *byteStream, int length);

#endif
